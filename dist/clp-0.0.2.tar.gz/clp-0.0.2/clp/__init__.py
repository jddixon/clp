# clp/cp/__init__.py

__version__ = '0.0.2'
__version_date__ = '2016-10-13'


class CLPError(RuntimeError):
    pass
