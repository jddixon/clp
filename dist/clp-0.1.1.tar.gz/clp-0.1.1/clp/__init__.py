# clp/cp/__init__.py

__version__ = '0.1.1'
__version_date__ = '2016-10-16'


class CLPError(RuntimeError):
    pass
