# clp/cp/__init__.py

__version__ = '0.1.0'
__version_date__ = '2016-10-14'


class CLPError(RuntimeError):
    pass
