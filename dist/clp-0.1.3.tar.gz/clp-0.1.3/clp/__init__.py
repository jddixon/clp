# clp/cp/__init__.py

__version__ = '0.1.3'
__version_date__ = '2016-10-18'


class CLPError(RuntimeError):
    pass
