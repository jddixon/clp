# clp/cp/__init__.py

__version__ = '0.1.4'
__version_date__ = '2016-11-06'


class CLPError(RuntimeError):
    pass
